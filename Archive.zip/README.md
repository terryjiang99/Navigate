# Right-Side-Menu-Open-in-swift-3
Right Slide Out Menu (Swift 3.0  in Xcode8 : SWRevealViewController)
